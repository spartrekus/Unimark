

char *strtxt2tex(char *str)
{  
      char ptr[ 2* strlen(str)+1];
      int i,j=0;
      for(i=0; str[i]!='\0'; i++)
      {
        //if ( str[i] == '%' ) 
//	{
          //ptr[j++]='\\';
 //         ptr[j++]=' ';
//	}
        if ( str[i] == '{' ) 
	{
          ptr[j++]='\\';
          ptr[j++]='{';
	}
        else if ( str[i] == '�' ) 
	{
          ptr[j++]='$';
          ptr[j++]='\\';
          ptr[j++]='m';
          ptr[j++]='u';
          ptr[j++]='$';
	}
        else if ( str[i] == '}' ) 
	{
          ptr[j++]='\\';
          ptr[j++]='}';
	}
        else if ( str[i] == '_' ) 
	{
          ptr[j++]='\\';
          ptr[j++]='_';
	}
        else if ( str[i] == '&' ) 
	{
          ptr[j++]='\\';
          ptr[j++]='&';
	}
        else
	{
          ptr[j++]=str[i];
	}
      } 
      ptr[j]='\0';
      size_t siz = 1 + sizeof ptr ; 
      char *r = malloc( 1 +  sizeof ptr );
      return r ? memcpy(r, ptr, siz ) : NULL;
}





