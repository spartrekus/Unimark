

//////////////////////////////////
//////////////////////////////////
// UNIMARK IS A POWERFUL MARKUP //
// AUTHOR: Spartrekus           //
// GNU LICENCE                  //
// Date: 2017 - June - 25       //
// Aim: 2017 - June - 25        //
//   For Making Thesis Easily   //
//   and more                   //
// Destined to Amiga, Sun, .... //
// Atari, CPC, ... having C     //
//////////////////////////////////
//////////////////////////////////

//  zip unimark-source-spartrekus-v0.1.zip                 bin/unimark  src/unimark.c src/test.mrk src/test.out

#include<stdio.h>
#include<string.h>
#include <stdlib.h>
#include <dirent.h>

// #define PAMAX 250
// for fexist
#include <ctype.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>

#include <unistd.h>  //define getcwd

//#include <time.h>
//#include "../lib/libcore.c"
//#include "../lib/libtime.c"


int fexist(char *a_option)
{
  char dir1[PATH_MAX]; 
  char *dir2;
  DIR *dip;
  strncpy( dir1 , "",  PATH_MAX  );
  strncpy( dir1 , a_option,  PATH_MAX  );

  struct stat st_buf; 
  int status; 
  int fileordir = 0 ; 

  status = stat ( dir1 , &st_buf);
  if (status != 0) {
    fileordir = 0;
  }

  // this is compatible to check if a file exists
  FILE *fp2check = fopen( dir1  ,"r");
  if( fp2check ) {
  // exists
  fileordir = 1; 
  fclose(fp2check);
  } 

  if (S_ISDIR (st_buf.st_mode)) {
    fileordir = 2; 
  }
return fileordir;
/////////////////////////////
}


int strcount( char *str , int mychar )
{  
      int return_strcount = 0;
      char ptr[strlen(str)+1];
      int i,j = 0;
      for(i=0; str[i]!='\0'; i++)
      {
        if ( str[i] == mychar ) return_strcount++;
      } 
      return return_strcount;
}




char *strcut( char *str , int myposstart, int myposend )
{  
      char ptr[strlen(str)+1];
      int i,j=0;
      for(i=0; str[i]!='\0'; i++)
      {
        if ( ( str[i] != '\0' ) && ( str[i] != '\0') )
         if ( ( i >=  myposstart-1 ) && (  i <= myposend-1 ) )
           ptr[j++]=str[i];
      } 
      ptr[j]='\0';
      size_t siz = sizeof ptr ; 
      char *r = malloc( sizeof ptr );
      return r ? memcpy(r, ptr, siz ) : NULL;
}



char *strtrim(char *str)
{  
      // right side to to finish
      char ptr[strlen(str)+1];
      int strposmax = strlen( str );
      int lastposchar = strposmax;
      int i,j=0;
      int foundspace = 1;

      /// find last char
      foundspace = 1;
      for( i= strposmax-1 ; i >= 0 ; i--)
      {
         //printf( "|%d-%d-%c| ", i , lastposchar , str[i] );
	 // find where to space
         if ( foundspace == 1 ) 
         if ( str[i] == ' ' ) 
   	    lastposchar = i-1;

         if ( str[i] != ' ' ) 
           foundspace = 0;
      } 

      // add the content
      foundspace = 1;
      for(i=0; i <= lastposchar ; i++)
      {
        if ( foundspace == 1 ) 
        if ( str[i] != ' ' ) 
          foundspace = 0;

        if ( foundspace == 0 ) 
           ptr[j++]=str[i];
      } 
      ptr[j]='\0';

      size_t siz = sizeof ptr ; 
      char *r = malloc( sizeof ptr );
      return r ? memcpy(r, ptr, siz ) : NULL;
}



/////////////////////////////////////
void filenew( char *fileout)
{
    FILE *fp5;
    fp5 = fopen( fileout , "wb+");
    fclose( fp5 );
}



///////////////////////////////////////////////////////////////////
void filerawcat(  char *fileout, char *filein )
{
  int fetchi;
  FILE *fp5;
  FILE *fp6;
  char fetchline[PATH_MAX];
  char fetchlinetmp[PATH_MAX];

  /////////////////////////////////////////////////
  if ( fexist( filein ) == 1 )
  {
    fp5 = fopen( fileout , "ab+");
    fp6 = fopen( filein , "rb");
    while( !feof(fp6) ) 
    {
          fgets(fetchlinetmp, PATH_MAX, fp6); 
          strncpy( fetchline, "" , PATH_MAX );
          for( fetchi = 0 ; ( fetchi <= strlen( fetchlinetmp ) ); fetchi++ )
            if ( fetchlinetmp[ fetchi ] != '\n' )
              fetchline[fetchi]=fetchlinetmp[fetchi];

         if ( !feof(fp6) )
         {
 	      fputs( fetchline , fp5 );
  	      fputs( "\n", fp5 );
	 }
     }
     fclose( fp5 );
     fclose( fp6 );
   }
}





char *strrlf(char *str)
{  // seems to work
      char ptr[strlen(str)+1];
      int i,j=0;
      for(i=0; str[i]!='\0'; i++)
      {
        if (str[i] != '\n' && str[i] != '\n') 
        ptr[j++]=str[i];
      } 
      ptr[j]='\0';
      size_t siz = sizeof ptr ; 
      char *r = malloc( sizeof ptr );
      return r ? memcpy(r, ptr, siz ) : NULL;
}


/////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////
char *strsplit(char *str , int mychar , int myitemfoo )
{  
      char ptr[strlen(str)+1];
      int myitem = myitemfoo +1;
      int i,j=0;
      int fooitem = 0;
      for(i=0; str[i]!='\0'; i++)
      {
        if ( str[i] == mychar ) 
           fooitem++;
        //else if ( str[i] != mychar &&  fooitem == myitem-1  ) 
        else if ( str[i] != mychar &&  fooitem == myitem-2  ) 
           ptr[j++]=str[i];
      } 
      ptr[j]='\0';
      size_t siz = sizeof ptr ; 
      char *r = malloc( sizeof ptr );
      return r ? memcpy(r, ptr, siz ) : NULL;
}






/// customed one
char *strdelimit(char *str , int mychar1, int mychar2,  int mycol )
{ 
      char ptr[strlen(str)+1];
      char ptq[strlen(str)+1];
      strncpy( ptr, strsplit( str, mychar1 , mycol+1 ), strlen(str)+1 );
      strncpy( ptq, strsplit( ptr, mychar2 , 1 ), strlen(str)+1 );
      size_t siz = sizeof ptq ; 
      char *r = malloc( sizeof ptq );
      return r ? memcpy(r, ptq, siz ) : NULL;
}







char *fbasename(char *name)
{
  //char *name;
  char *base = name;
  while (*name)
    {
      if (*name++ == '/')
	{
	  base = name;
	}
    }
  return (base);
}



char *fextension(char *str)
{ 
      //seems to work
      char ptr[strlen(str)+1];
      int i,j=0;
      for(i=strlen(str)-1 ; str[i] !='.' ; i--)
      {
        if ( str[i] != '.' ) 
            ptr[j++]=str[i];
      } 
      ptr[j]='\0';

      char ptrout[strlen(ptr)+1];  
      j = 0; 
      for( i=strlen(ptr)-1 ;  i >= 0 ; i--)
            ptrout[j++]=ptr[i];
      ptrout[j]='\0';

      size_t siz = sizeof ptrout ; 
      char *r = malloc( sizeof ptrout );
      return r ? memcpy(r, ptrout, siz ) : NULL;
}





char *filename_newext( char *str , char *newext )
{
      //seems to work
      char ptr[strlen(str)+1];
      int i,j=0;
      int foundpoint = 0; 
      for(i=strlen(str)-1 ; i!=-1 ; i--)
      {
          if ( str[i] == '.' ) foundpoint = i; 
      } 

     if ( foundpoint >= 1 ){
      int maxsize = strlen(str)+1+strlen(newext) ;
      char ptrnew[ maxsize ];
      strncpy( ptrnew, strcut( str, 1, foundpoint+1 ),  maxsize  ); 

      ptrnew[ foundpoint ] = '.';
      for(i=0 ; i<= strlen( newext)-1 ; i++)
         ptrnew[ foundpoint+1 +i ] = newext[ i ];
      ptrnew[ foundpoint +i+1] = '\0';

       size_t siz = sizeof ptrnew ; 
       char *r = malloc( sizeof ptrnew );
       return r ? memcpy(r, ptrnew, siz ) : NULL;
    } else return ""; 
}








///////////////////////////////////////////////////////////////////
void nfileunimark( char *fileout, char *filein )
{
  int fetchi;
  FILE *fp5;
  FILE *fp6;
  char fetchline[PATH_MAX];
  char fetchlinetmp[PATH_MAX];

  char charin[PATH_MAX];
  char charout[PATH_MAX];
  char lineout[PATH_MAX];

  int foundcode = 0; 
  int beginitemize = 0; 

  /////////////////////////////////////////////////
  if ( fexist( filein ) == 1 )
  {
    //fp5 = fopen( fileout , "wb");
    //fclose( fp5 );
    fp5 = fopen( fileout , "ab");
    fp6 = fopen( filein , "rb");
    while( !feof(fp6) ) 
    {
	  foundcode = 0; 
          fgets(fetchlinetmp, PATH_MAX, fp6); 
          strncpy( fetchline, "" , PATH_MAX );
          for( fetchi = 0 ; ( fetchi <= strlen( fetchlinetmp ) ); fetchi++ )
            if ( fetchlinetmp[ fetchi ] != '\n' )
              fetchline[fetchi]=fetchlinetmp[fetchi];


           if ( !feof(fp6) )
           {
            /// new mysection
            // !sec    (why !, because it can be into the standard 250 chars)  
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 's' )
            if ( fetchline[2] == 'e' )
            if ( fetchline[3] == 'c' )
            if ( fetchline[4] == ' ' )
            {
 	      fputs( "\\section{" , fp5 );
 	      fputs( strtrim( strcut( fetchline, 4+2, strlen(fetchline))) , fp5 );
  	      fputs( "}\n", fp5 );
  	      foundcode = 1;
            }


            if ( foundcode == 0 )
	    if ( 
            ( ( fetchline[0] == '!' )
            && ( fetchline[1] == 'i' )
            && ( fetchline[2] == 'n' )
            && ( fetchline[3] == 'p' )
            && ( fetchline[4] == 'u' )
            && ( fetchline[5] == 't' )
            && ( fetchline[6] == '{' )
	    )
	    )
            {
 	      //fputs( strbraket( fetchline ) , fp5 );
 	      //fputs( strdelimit( fetchline,  '{' ,'}' ,  1 ) , fp5 );
              fclose( fp5 );                 /// writer
              long saved = ftell( fp6 );     /// reader
              fclose( fp6 );                 /// reader

	      char fileinputsrc[PATH_MAX];
	      strncpy( fileinputsrc, "", PATH_MAX );
              strncat( fileinputsrc , strdelimit( fetchline,  '{' ,'}' ,  1 ) , PATH_MAX - strlen( fileinputsrc ) -1 );
	      if ( fileinputsrc[0] == '~' )
	      {
	         strncpy( fileinputsrc, "", PATH_MAX );
                 strncat( fileinputsrc , getenv( "HOME" ) , PATH_MAX - strlen( fileinputsrc ) -1 );
                 strncat( fileinputsrc , strdelimit( fetchline,  '~' ,'}' ,  1 ) , PATH_MAX - strlen( fileinputsrc ) -1 );
	      }
                //filetexiex( fileout, strdelimit( fetchline,  '{' ,'}' ,  1 ) );
		// !input 
		printf( "!input{%s} (fexist:%d) (...)\n", fileinputsrc , fexist( fileinputsrc ) );
                nfileunimark( fileout, fileinputsrc );
              fp5 = fopen( fileout , "ab+"); /// writer
              fp6 = fopen( filein , "r");  /// reader
              fseek( fp6 , saved , SEEK_SET); // reader 
  	      foundcode = 1;
            }





            // //  for comment mycomment
            if ( foundcode == 0 )
            if ( fetchline[0] == '/' )
            if ( fetchline[1] == '/' )
            {
  	      foundcode = 1;
            }


            /// new item
            // !subsec 
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 's' )
            if ( fetchline[2] == 'u' )
            if ( fetchline[3] == 'b' )
            if ( fetchline[4] == 's' )
            if ( fetchline[5] == 'e' )
            if ( fetchline[6] == 'c' )
            if ( fetchline[7] == ' ' )
            {
 	      fputs( "\\subsection{" , fp5 );
 	      fputs( strtrim( strcut( fetchline, 7+2, strlen(fetchline))) , fp5 );
  	      fputs( "}\n", fp5 );
  	      foundcode = 1;
            }



            /// new item
            // !subsubsec 
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 's' )
            if ( fetchline[2] == 'u' )
            if ( fetchline[3] == 'b' )
            if ( fetchline[4] == 's' )
            if ( fetchline[5] == 'u' )
            if ( fetchline[6] == 'b' )
            if ( fetchline[7] == 's' )
            if ( fetchline[8] == 'e' )
            if ( fetchline[9] == 'c' )
            if ( fetchline[10] == ' ' )
            {
 	      fputs( "\\subsubsection{" , fp5 );
 	      fputs( strtrim( strcut( fetchline, 10+2, strlen(fetchline))) , fp5 );
  	      fputs( "}\n", fp5 );
  	      foundcode = 1;
            }


            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'c' )
            if ( fetchline[2] == 'h' )
            if ( fetchline[3] == 'a' )
            if ( fetchline[4] == 'p' )
            if ( fetchline[5] == ' ' )
            {
 	      fputs( "\\chapter{" , fp5 );
 	      fputs( strtrim( strcut( fetchline, 5+2, strlen(fetchline))) , fp5 );
  	      fputs( "}\n", fp5 );
  	      foundcode = 1;
            }

            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'c' )
            if ( fetchline[2] == 'i' )
            if ( fetchline[3] == 't' )
            if ( fetchline[4] == 'e' )
            if ( fetchline[5] == ' ' )
            {
 	      fputs( "\\unicite{" , fp5 );
 	      fputs( strtrim( strcut( fetchline, 4+2, strlen(fetchline))) , fp5 );
  	      fputs( "}\n", fp5 );
  	      foundcode = 1;
            }


            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'b' )
            if ( fetchline[2] == 'u' )
            if ( fetchline[3] == ' ' )
            {
 	      fputs( "\\unibullet{" , fp5 );
 	      fputs( strcut( fetchline, 3+2, strlen(fetchline)) , fp5 );
  	      fputs( "}\n", fp5 );
  	      foundcode = 1;
            }


            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'p' )
            if ( fetchline[2] == ' ' )
            {
 	      fputs( "\\unipara{" , fp5 );
 	      fputs( strcut( fetchline, 2+2, strlen(fetchline)) , fp5 );
  	      fputs( "}\n", fp5 );
  	      foundcode = 1;
            }

            // !fig{myfig.jpg}
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'f' )
            if ( fetchline[2] == 'i' )
            if ( fetchline[3] == 'g' )
            if ( fetchline[4] == '{' )
            {
 	      fputs( "\\unifig{" , fp5 );
 	      fputs( strdelimit( fetchline,  '{' ,'}' ,  1 ) , fp5 );
  	      fputs( "}\n", fp5 );
  	      foundcode = 1;
            }
            // !zfig{myfig.jpg}
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'z' )
            if ( fetchline[2] == 'f' )
            if ( fetchline[3] == 'i' )
            if ( fetchline[4] == 'g' )
            if ( fetchline[5] == '{' )
            {
	      if ( strcount( fetchline, '}' ) >= 3 )
	      {
 	        fputs( "\\unizfig{" , fp5 );
 	        fputs( strdelimit( fetchline,  '{' ,'}' ,  1 ) , fp5 );
  	        fputs( "}{", fp5 );
 	        fputs( strdelimit( fetchline,  '{' ,'}' , 2 ) , fp5 );
  	        fputs( "}", fp5 );
  	        fputs( "{", fp5 );
 	        fputs( strdelimit( fetchline,  '{' ,'}' , 3 ) , fp5 );
		fputs( "}", fp5 );
  	        fputs( "\n", fp5 );
	      }
	      else if ( strcount( fetchline, '}' ) == 1 )
	      {
 	        fputs( "\\unifig{" , fp5 );
 	        fputs( strdelimit( fetchline,  '{' ,'}' ,  1 ) , fp5 );
  	        fputs( "}", fp5 );
  	        fputs( "\n", fp5 );
	      }
  	      foundcode = 1;
            }





            // >  for beginitemize
            if ( foundcode == 0 )
            if ( fetchline[0] == '>' )
            if ( fetchline[1] == ' ' )
            {
	      //if ( beginitemize == 0 ) fputs( "\\unibeginitemize\n" , fp5 ); 
	      if ( beginitemize == 0 )
	      {
 	        fputs( "\\unihead{" , fp5 );
 	        fputs( strcut( fetchline, 1+2, strlen(fetchline)) , fp5 );
  	        fputs( "}\n", fp5 );
	        fputs( "\\begin{itemize}\n" , fp5 ); 
	      }
	      beginitemize = 1;
  	      foundcode = 1;
            }
	    // myitem 
            // -  for beginitemize
            if ( foundcode == 0 )
	    if ( beginitemize == 1 )
            if ( fetchline[0] == '-' )
            if ( fetchline[1] == ' ' )
            {
 	      fputs( "\\item " , fp5 );
 	      fputs( strtrim( strcut( fetchline, 1+2, strlen(fetchline))) , fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }
            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'l' )
            if ( fetchline[2] == 'i' )
            if ( fetchline[3] == ' ' )
            {
 	      fputs( "\\uniitem{" , fp5 );
 	      fputs( strcut( fetchline, 3+2, strlen(fetchline)) , fp5 );
  	      fputs( "}\n", fp5 );
 	      //fputs( "\\item " , fp5 );
 	      //fputs( strcut( fetchline, 3+2, strlen(fetchline)) , fp5 );
  	      //fputs( "\n", fp5 );
  	      foundcode = 1;
            }


            if ( foundcode == 0 )
            if ( fetchline[0] == '!' )
            if ( fetchline[1] == 'e' )
            if ( fetchline[2] == 'n' )
            if ( fetchline[3] == 'd' )
            {
 	      fputs( "\\uniend" , fp5 );
  	      fputs( "\n", fp5 );
  	      foundcode = 1;
            }


	    //if ( strcmp( lineout , "" ) != 0 )
	    //if ( strcmp( lineout , "\n" ) != 0 )
	    if ( foundcode == 0 )
	    {
	        //if ( beginitemize == 1 ) fputs( "\\unienditemize\n" , fp5 ); 
	        if ( beginitemize == 1 ) fputs( "\\end{itemize}\n" , fp5 ); 
 	        //fputs( "|" , fp5 );
 	        fputs( fetchline , fp5 );
 	        //fputs( "|" , fp5 );
  	        fputs( "\n", fp5 );
	        beginitemize = 0;
             }
	   }
     }
     fclose( fp5 );
     fclose( fp6 );
   }
}









int main( int argc, char *argv[])
{
    char cwd[PATH_MAX];

    ////////////////////////////////////////////////////////
    //  zip unimark-source-spartrekus-v0.1.zip                 bin/unimark  src/unimark.c src/test.mrk src/test.out
    ////////////////////////////////////////////////////////
    if ( argc == 2)
      if ( strcmp( argv[1] , "--make" ) == 0 )
      {
          system(  "  zip unimark-source-spartrekus-v0.1.zip                 bin/unimark  src/unimark.c src/test.mrk src/test.out " );
          return 0;
      }


    printf("================= \n");
    printf("|||- UNIMARK -||| \n");
    printf("================= \n");
    printf("- An Universal Markup Language - \n");
    printf("- Cross-Platform, using plain C language - \n");
    printf("- Author: GITHUB Spartrekus - \n");
    printf("- LICENCE : GNU - \n");

    if ( argc == 3)
    {
     printf("- Please do not modify unimark too much, since \n" );
     printf("- it is intentionally made to be universal, largely portable, and minimalist.\n" );
     printf("- Choosen Style Output : TEX -\n" );
     printf("- (Currently there is only TeX available)-\n" );
     printf("- (Future: HTML to be available)-\n" );
    }


    ////////////////////////////////////////////////////////
    if ( argc == 3)
      if ( fexist( argv[1] ) == 1 )
      {
          printf("  >SRC: %s => TRG: %s \n", argv[1] , argv[2] );
          filenew( argv[2] );
          nfileunimark( argv[2] , argv[1] );
          return 0;
      }

    if ( argc == 2)      printf( "Usage: unimark filein.mrk fileout.tex \n" );
    else if ( argc == 1) printf( "Usage: unimark filein.mrk fileout.tex \n" );
    return 0;

}






